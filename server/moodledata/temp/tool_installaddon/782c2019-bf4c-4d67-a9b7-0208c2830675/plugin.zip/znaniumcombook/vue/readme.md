To download prerequisites:
    
    npm install

To build debug version:

    npm run dev
    
To build production version:

    npm run prod
    
